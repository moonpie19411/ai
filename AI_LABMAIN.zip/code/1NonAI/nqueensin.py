def print_solution(board):
    for row in board:
        for col in row:
            if col == 1:
                print(" Q ", end=" ")
            else:
                print(" . ", end=" ")
        print()

def solve_nq_util(board, col, ld, rd, cl, N):
    # Base case: If all queens are placed, return true
    if col >= N:
        return True

    # Try placing the queen in each row
    for row in range(N):
        # Check if it's safe to place a queen
        if ld[row - col + N - 1] == 0 and rd[row + col] == 0 and cl[row] == 0:
            # Place the queen
            board[row][col] = 1
            ld[row - col + N - 1] = rd[row + col] = cl[row] = 1

            # Recur to place the next queen
            if solve_nq_util(board, col + 1, ld, rd, cl, N):
                return True

            # Backtrack
            board[row][col] = 0
            ld[row - col + N - 1] = rd[row + col] = cl[row] = 0

    return False

def solve_n_queens(N):
    # Validate board size
    if N == 2 or N == 3:
        print(f"No solution exists for N = {N}")
        return

    # Initialize the board with zeros
    board = [[0] * N for _ in range(N)]

    # Initialize attack arrays
    ld = [0] * (2 * N)  # Left diagonal
    rd = [0] * (2 * N)  # Right diagonal
    cl = [0] * N        # Columns

    # Solve the N-Queens problem
    if solve_nq_util(board, 0, ld, rd, cl, N):
        print_solution(board)
    else:
        print("Solution does not exist")

# Get the size of the board (N) from the user
N = int(input("Enter the size of the board (N): "))

# Solve the N-Queens problem
solve_n_queens(N)
