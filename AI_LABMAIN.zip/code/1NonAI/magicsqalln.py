def generate_magic_square(n):
    if n <= 0:
        print("The size must be a positive integer.")
        return
    
    magic_square = [[0] * n for _ in range(n)]
    
    # Case 1: Odd order (Siamese method)
    if n % 2 == 1:
        i, j = 0, n // 2
        for num in range(1, n * n + 1):
            magic_square[i][j] = num
            new_i, new_j = i - 1, j + 1
            
            # Wrap around if out of bounds
            if new_i < 0 and new_j == n:
                new_i, new_j = i + 1, j
            else:
                if new_i < 0:
                    new_i = n - 1
                if new_j == n:
                    new_j = 0
            
            # If cell is occupied, move down
            if magic_square[new_i][new_j] != 0:
                new_i, new_j = i + 1, j
            
            i, j = new_i, new_j
    
    # Case 2: Doubly-even order (n divisible by 4)
    elif n % 4 == 0:
        # Fill the square sequentially
        for i in range(n):
            for j in range(n):
                magic_square[i][j] = i * n + j + 1
        
        # Swap elements to make it magic
        for i in range(n // 4):
            for j in range(n // 4):
                # Swap in 4x4 blocks
                magic_square[i][j] = n * n + 1 - magic_square[i][j]
                magic_square[i][n - 1 - j] = n * n + 1 - magic_square[i][n - 1 - j]
                magic_square[n - 1 - i][j] = n * n + 1 - magic_square[n - 1 - i][j]
                magic_square[n - 1 - i][n - 1 - j] = n * n + 1 - magic_square[n - 1 - i][n - 1 - j]
    
    # Case 3: Singly-even order (even but not divisible by 4)
    else:
        # Strachey method
        k = n // 2
        sub_square = generate_magic_square(k)
        
        # Divide into 4 sub-squares (A, B, C, D)
        for i in range(k):
            for j in range(k):
                magic_square[i][j] = sub_square[i][j]  # A
                magic_square[i + k][j + k] = sub_square[i][j] + k * k  # D
                magic_square[i][j + k] = sub_square[i][j] + 2 * k * k  # B
                magic_square[i + k][j] = sub_square[i][j] + 3 * k * k  # C
        
        # Adjustments for singly-even
        shift = (n - 2) // 4
        for i in range(k):
            for j in range(shift):
                # Swap left side
                magic_square[i][j], magic_square[i + k][j] = magic_square[i + k][j], magic_square[i][j]
        
        # Swap middle row
        mid = k // 2
        for j in range(shift - 1, shift + mid + 1):
            magic_square[mid][j], magic_square[mid + k][j] = magic_square[mid + k][j], magic_square[mid][j]
        
        # Swap last shift-1 columns
        for i in range(k):
            for j in range(n - shift + 1, n):
                magic_square[i][j], magic_square[i + k][j] = magic_square[i + k][j], magic_square[i][j]
    
    # Print the magic square
    print(f"\nMagic Square (n = {n}):")
    print(f"Magic Constant (Sum of rows/columns/diagonals) = {n * (n * n + 1) // 2}")
    for row in magic_square:
        print(" ".join(f"{num:3d}" for num in row))

if __name__ == "__main__":
    n = int(input("Enter the size of the Magic Square: "))
    generate_magic_square(n)