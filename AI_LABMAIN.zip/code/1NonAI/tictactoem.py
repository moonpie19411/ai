import tkinter as tk
from tkinter import messagebox

class TicTacToe:
    #sets game window,initializes everything,cals create_board to draw buttond on gui
    def __init__(self, root):
        self.root = root
        self.root.title("Tic Tac Toe - 2 Player")
        self.current_player = 'X'
        self.board = [['' for _ in range(3)] for _ in range(3)]

        self.buttons = [[None for _ in range(3)] for _ in range(3)]
        self.create_board()
# 3x3 grid,calls makemove(rows,column)
    def create_board(self):
        for i in range(3):
            for j in range(3):
                btn = tk.Button(self.root, text='', font=('Helvetica', 24), width=5, height=2,
                                command=lambda r=i, c=j: self.make_move(r, c))
                btn.grid(row=i, column=j)
                self.buttons[i][j] = btn
#handles players move>check for win/draw>swap turns
    def make_move(self, row, col):
        if self.buttons[row][col]['text'] == '':
            self.buttons[row][col]['text'] = self.current_player
            self.board[row][col] = self.current_player
            if self.check_winner(row, col):
                messagebox.showinfo("Game Over", f"Player {self.current_player} wins!")
                self.reset_board()
            elif all(cell != '' for row in self.board for cell in row):
                messagebox.showinfo("Game Over", "It's a draw!")
                self.reset_board()
            else:
                self.current_player = 'O' if self.current_player == 'X' else 'X'

    def check_winner(self, row, col):
        b = self.board
        n = 3
        # CONDITIONS:Check row, col, and diagonals[main,anti]
        return (all(b[row][i] == self.current_player for i in range(n)) or
                all(b[i][col] == self.current_player for i in range(n)) or
                all(b[i][i] == self.current_player for i in range(n)) or
                all(b[i][n-1-i] == self.current_player for i in range(n)))
    #fresh start
    def reset_board(self):
        self.current_player = 'X'
        self.board = [['' for _ in range(3)] for _ in range(3)]
        for row in self.buttons:
            for btn in row:
                btn.config(text='')

# Run the game
root = tk.Tk()
game = TicTacToe(root)
root.mainloop()
