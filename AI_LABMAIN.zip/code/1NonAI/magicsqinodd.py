def generate_magic_square(n):
    # Initialize the magic square with zeros
    magic_square = [[0] * n for _ in range(n)]
    
    # Starting position (middle column of the top row)
    i, j = 0, n // 2
    
    # Fill the magic square
    for num in range(1, n * n + 1):
        magic_square[i][j] = num
        
        # Calculate next position (move up-right)
        new_i, new_j = i - 1, j + 1
        
        # Handle out-of-bound cases
        if new_i < 0 and new_j == n:  # If both go out of bounds
            new_i, new_j = i + 1, j
        else:
            if new_i < 0:  # Wrap around vertically
                new_i = n - 1
            if new_j == n:  # Wrap around horizontally
                new_j = 0
        
        # If the next cell is already filled, move down instead
        if magic_square[new_i][new_j] != 0:
            new_i, new_j = i + 1, j
        
        # Update current position
        i, j = new_i, new_j
    
    # Print the magic square
    print(f"The Magic Square for {n}:")
    print(f"Sum of each row or column: {n * (n * n + 1) // 2}")
    for row in magic_square:
        print(" ".join(map(str, row)))

# Driver code
if __name__ == "__main__":
    n = int(input("Enter an odd number for the size of the Magic Square: "))
    
    # Ensure the input is a positive odd number
    if n % 2 == 0 or n <= 0:
        print("The input must be a positive odd number.")
    else:
        generate_magic_square(n)