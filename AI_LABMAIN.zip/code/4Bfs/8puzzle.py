import heapq
from copy import deepcopy

class PuzzleState:
    def __init__(self, board, parent=None, move=None, depth=0):
        self.board = board
        self.parent = parent
        self.move = move
        self.depth = depth
        self.heuristic = self.calculate_manhattan_distance()
        self.priority = self.heuristic  # Best-First uses heuristic only
    
    def __lt__(self, other):
        return self.priority < other.priority
    
    def calculate_manhattan_distance(self):
        goal_pos = {1:(0,0), 2:(0,1), 3:(0,2),
                    4:(1,0), 5:(1,1), 6:(1,2),
                    7:(2,0), 8:(2,1), 0:(2,2)}
        distance = 0
        for i in range(3):
            for j in range(3):
                val = self.board[i][j]
                if val != 0:
                    goal_i, goal_j = goal_pos[val]
                    distance += abs(i - goal_i) + abs(j - goal_j)
        return distance
    
    def get_blank_pos(self):
        for i in range(3):
            for j in range(3):
                if self.board[i][j] == 0:
                    return (i, j)
    
    def get_neighbors(self):
        neighbors = []
        blank_i, blank_j = self.get_blank_pos()
        moves = {'UP':(-1,0), 'DOWN':(1,0), 'LEFT':(0,-1), 'RIGHT':(0,1)}
        
        for move, (di, dj) in moves.items():
            new_i, new_j = blank_i + di, blank_j + dj
            if 0 <= new_i < 3 and 0 <= new_j < 3:
                new_board = deepcopy(self.board)
                new_board[blank_i][blank_j], new_board[new_i][new_j] = \
                    new_board[new_i][new_j], new_board[blank_i][blank_j]
                neighbors.append(PuzzleState(new_board, self, move, self.depth + 1))
        
        return neighbors
    
    def get_path(self):
        path = []
        current = self
        while current:
            if current.move:
                path.append((current.move, current.board))
            current = current.parent
        return path[::-1]

def print_board(board):
    for row in board:
        print(" ".join(str(x) if x != 0 else " " for x in row))
    print()

def best_first_search(initial_state):
    open_list = []
    heapq.heappush(open_list, initial_state)
    closed_set = set()
    
    while open_list:
        current_state = heapq.heappop(open_list)
        
        if current_state.heuristic == 0:
            return current_state.get_path()
        
        board_tuple = tuple(tuple(row) for row in current_state.board)
        if board_tuple in closed_set:
            continue
            
        closed_set.add(board_tuple)
        
        for neighbor in current_state.get_neighbors():
            neighbor_tuple = tuple(tuple(row) for row in neighbor.board)
            if neighbor_tuple not in closed_set:
                heapq.heappush(open_list, neighbor)
    
    return None

# User Input
print("Enter initial board state (3 rows, space-separated, 0 for blank):")
initial_board = []
for _ in range(3):
    row = list(map(int, input().split()))
    initial_board.append(row)

initial_state = PuzzleState(initial_board)
solution = best_first_search(initial_state)

if solution:
    print("\nSolution Path:")
    print("Initial State:")
    print_board(initial_board)
    for step, (move, board) in enumerate(solution, 1):
        print(f"Step {step}: Move {move}")
        print_board(board)
else:
    print("No solution exists for this puzzle configuration.")
    
"""
input:

Enter initial board state (3 rows, space-separated, 0 for blank):
1 2 3
7 8 0
4 5 6

"""