import heapq

def heuristic(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])  # Manhattan distance

def print_grid(grid, path_positions):
    for i in range(len(grid)):
        for j in range(len(grid[0])):
            if (i, j) in path_positions:
                print("R", end=" ")  # Mark the robot's path
            elif grid[i][j] == 1:
                print("X", end=" ")  # Mark obstacles
            else:
                print(".", end=" ")  # Open space
        print()
    print("\n" + "-" * 20 + "\n")

def best_first_search_robot(grid, start, goal):
    pq = []
    heapq.heappush(pq, (0, start))
    visited = set()
    parent = {start: None}

    while pq:
        _, current = heapq.heappop(pq)

        if current == goal:
            path = []
            while current:
                path.append(current)
                current = parent[current]
            return path[::-1]  # Reverse the path to start from initial position

        visited.add(current)
        x, y = current
        moves = [(0, 1), (0, -1), (1, 0), (-1, 0)]

        for dx, dy in moves:
            nx, ny = x + dx, y + dy
            if 0 <= nx < len(grid) and 0 <= ny < len(grid[0]) and grid[nx][ny] == 0 and (nx, ny) not in visited:
                heapq.heappush(pq, (heuristic((nx, ny), goal), (nx, ny)))
                parent[(nx, ny)] = current

    return None

# User Input
print("Enter grid size (rows and cols):")
rows, cols = map(int, input().split())

grid = []
print("Enter grid (0 for free space, 1 for obstacle):")
for _ in range(rows):
    grid.append(list(map(int, input().split())))

print("Enter start position (x y):")
sx, sy = map(int, input().split())
print("Enter goal position (x y):")
gx, gy = map(int, input().split())

path = best_first_search_robot(grid, (sx, sy), (gx, gy))

if path:
    print("\nStep-by-step robot navigation:\n")
    for step in path:
        print(f"Robot moves to: {step}")
        print_grid(grid, path[:path.index(step) + 1])
    print("Goal Reached!")
else:
    print("No path found!")


"""
input 1:

Enter grid size (rows and cols):
3 3 
Enter grid (0 for free space, 1 for obstacle):
1 0 1
1 0 0
1 1 0
Enter start position (x y):
0 1
Enter goal position (x y):
2 2
"""
"""
input 2:

Enter grid size (rows and cols):
3 3 
Enter grid (0 for free space, 1 for obstacle):
1 0 1
1 0 0
1 1 0
Enter start position (x y):
0 1
Enter goal position (x y):
2 2
"""
