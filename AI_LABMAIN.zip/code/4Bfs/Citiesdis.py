import heapq

def best_first_search_city(start, goal, graph, heuristics):
    """Perform best-first search on the graph to find a path to the goal city."""
    pq = [(heuristics[start], start)]
    visited = set()

    while pq:
        h, city = heapq.heappop(pq)
        print("Visiting:", city)

        if city == goal:
            print("Goal reached!")
            return

        visited.add(city)

        for neighbor, _ in graph.get(city, []):
            if neighbor not in visited:
                heapq.heappush(pq, (heuristics[neighbor], neighbor))

def main():
    # Take input for the graph
    graph = {}
    print("Enter the graph (one city at a time). Enter 'done' when finished.")
    while True:
        city = input("Enter city (or 'done' to finish): ").strip().upper()
        if city == 'DONE':
            break
        neighbors = []
        print(f"Enter neighbors for city {city} (format: 'neighbor1,cost1 neighbor2,cost2 ...')")
        neighbors_input = input().strip()
        if neighbors_input:
            for neighbor_cost in neighbors_input.split():
                neighbor, cost = neighbor_cost.split(',')
                neighbors.append((neighbor.strip().upper(), int(cost)))
        graph[city] = neighbors

    # Take input for heuristic values
    heuristics = {}
    print("\nEnter heuristic values for each city (format: 'city1,value1 city2,value2 ...')")
    heuristics_input = input().strip()
    for city_value in heuristics_input.split():
        city, value = city_value.split(',')
        heuristics[city.strip().upper()] = int(value)

    # Take input for start and goal cities
    start = input("\nEnter start city: ").strip().upper()
    goal = input("Enter goal city: ").strip().upper()

    # Run the search
    print(f"\nStarting best-first search from {start} to {goal}...")
    best_first_search_city(start, goal, graph, heuristics)

if __name__ == "__main__":
    main()

"""
1.Enter the graph (one city at a time). Enter 'done' when finished.

Mumbai
Pune,3 Thane,2
Pune
Nashik,4 Thane,2  # Add Thane as neighbor of Pune
Thane
Nashik,3 Kalyan,1
Nashik
Aurangabad,6
Kolhapur
Sangli,2
Kalyan
Mumbai,2
Aurangabad
Nagpur,8
Sangli
Satara,3
Nagpur

Satara

done

2.Enter heuristic values for each city (format: 'city1,value1 city2,value2

Mumbai,0 Pune,100 Thane,20 Nashik,150 Kolhapur,300 Kalyan,10 Aurangabad,250 Sangli,350 Nagpur,600 Satara,400

3.Enter start city

PUNE
MUMBAI

"""