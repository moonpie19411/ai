import networkx as nx
import matplotlib.pyplot as plt

class MapColoringCSP:
    def __init__(self, regions, adjacencies, colors):
        """
        Initialize the Map Coloring CSP problem.
        
        :param regions: List of region names (e.g., ['WA', 'NT', 'SA', 'Q', 'NSW', 'V', 'T'])
        :param adjacencies: Dictionary mapping each region to its adjacent regions
                          (e.g., {'WA': ['NT', 'SA'], 'NT': ['WA', 'SA', 'Q'], ...})
        :param colors: List of available colors (e.g., ['red', 'green', 'blue'])
        """
        self.regions = regions
        self.adjacencies = adjacencies
        self.colors = colors
        self.assignment = {}
    
    def is_consistent(self, region, color):
        """
        Check if assigning 'color' to 'region' is consistent with current assignments.
        """
        for neighbor in self.adjacencies.get(region, []):
            if neighbor in self.assignment and self.assignment[neighbor] == color:
                return False
        return True
    
    def backtracking_search(self):
        """
        Perform backtracking search to find a valid coloring.
        """
        if len(self.assignment) == len(self.regions):
            return self.assignment
        
        unassigned = [r for r in self.regions if r not in self.assignment]
        first = unassigned[0]
        
        for color in self.colors:
            if self.is_consistent(first, color):
                self.assignment[first] = color
                result = self.backtracking_search()
                if result is not None:
                    return result
                del self.assignment[first]
        
        return None
    
    def solve(self):
        """
        Solve the CSP and return the coloring assignment or None if no solution exists.
        """
        self.assignment = {}
        return self.backtracking_search()

def get_user_input():
    """
    Get user input for regions, adjacencies, and colors.
    """
    regions_input = input("Enter region names separated by commas (e.g., WA,NT,SA,Q,NSW,V,T): ").strip()
    regions = [r.strip() for r in regions_input.split(',') if r.strip()]
    
    if not regions:
        raise ValueError("At least one region must be specified.")
    
    adjacencies = {}
    print("\nEnter adjacent regions for each region (comma separated).")
    for region in regions:
        neighbors_input = input(f"Adjacent regions for {region} (press enter if none): ").strip()
        neighbors = [n.strip() for n in neighbors_input.split(',') if n.strip()]
        adjacencies[region] = neighbors
    
    colors_input = input("\nEnter available colors separated by commas (e.g., red,green,blue): ").strip()
    colors = [c.strip() for c in colors_input.split(',') if c.strip()]
    
    if not colors:
        raise ValueError("At least one color must be specified.")
    
    return regions, adjacencies, colors

def visualize_solution(regions, adjacencies, solution):
    """
    Visualize the map coloring solution using networkx and matplotlib.
    """
    if not solution:
        print("No solution to visualize.")
        return
    
    G = nx.Graph()
    
    # Add nodes (regions)
    G.add_nodes_from(regions)
    
    # Add edges (adjacencies)
    for region, neighbors in adjacencies.items():
        for neighbor in neighbors:
            if neighbor in regions:  # Only add if neighbor exists
                G.add_edge(region, neighbor)
    
    # Create color mapping for nodes
    color_map = []
    for node in G:
        color_map.append(solution.get(node, 'gray'))  # Use gray for uncolored regions (shouldn't happen)
    
    # Draw the graph
    plt.figure(figsize=(10, 8))
    pos = nx.spring_layout(G)  # Positions for all nodes
    
    nx.draw(G, pos, with_labels=True, node_color=color_map, node_size=2000, 
            font_size=10, font_weight='bold', edge_color='gray')
    
    plt.title("Map Coloring Solution")
    plt.show()

def main():
    print("Map Coloring Problem Solver with Visualization")
    print("---------------------------------------------")
    
    try:
        regions, adjacencies, colors = get_user_input()
        
        csp = MapColoringCSP(regions, adjacencies, colors)
        solution = csp.solve()
        
        if solution:
            print("\nSolution found:")
            for region, color in solution.items():
                print(f"{region}: {color}")
            
            # Visualize the solution
            visualize_solution(regions, adjacencies, solution)
        else:
            print("\nNo valid coloring exists with the given constraints.")
    except ValueError as e:
        print(f"\nError: {e}")
    except Exception as e:
        print(f"\nAn unexpected error occurred: {e}")

if __name__ == "__main__":
    main()

"""
AI mapcoloring:Regions: WA,NT,SA,Q,NSW,V,T

NT,SA
WA,SA,Q
WA,NT,Q,NSW,V
NT,SA,NSW
Q,SA,V
SA,NSW
(none)

red,green,blue

input2:

AI mapcoloring:Regions: WA,NT,SA,Q,NSW,V,T

NT,SA
WA,SA,Q
WA,NT,Q,NSW,V
NT,SA,NSW
Q,SA,V
SA,NSW
NT

red,green,blue
"""