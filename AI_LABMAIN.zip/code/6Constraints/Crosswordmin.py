# Modified 5x5 layout (where '_' are empty spaces, and '#' are blocked cells)
crossword_layout = [
    ['_', '_', '_', '_', '_'],
    ['_', '#', '_', '#', '_'],
    ['_', '_', '_', '_', '_'],
    ['_', '#', '_', '#', '_'],
    ['_', '_', '_', '_', '_']
]

grid_size = len(crossword_layout)

# Function to check if a word can be placed in the grid
def is_valid(word, row, col, direction, grid):
    for k in range(len(word)):
        r, c = (row + k, col) if direction == 'V' else (row, col + k)
        if r >= grid_size or c >= grid_size or crossword_layout[r][c] == '#':
            return False
        if grid[r][c] not in ('', word[k]):
            return False
    return True

# Function to place the word
def place_word(word, row, col, direction, grid):
    placed = []
    for k in range(len(word)):
        r, c = (row + k, col) if direction == 'V' else (row, col + k)
        if grid[r][c] == '':
            grid[r][c] = word[k]
            placed.append((r, c))
    return placed

# Function to remove a word
def remove_word(placed, grid):
    for r, c in placed:
        grid[r][c] = ''

# CSP backtracking solver
def solve_csp(index, grid, words):
    if index == len(words):
        return True
    word = words[index]
    for i in range(grid_size):
        for j in range(grid_size):
            for direction in ['H', 'V']:
                if is_valid(word, i, j, direction, grid):
                    placed = place_word(word, i, j, direction, grid)
                    if solve_csp(index + 1, grid, words):
                        return True
                    remove_word(placed, grid)
    return False

# Main function for terminal version
def main():
    print("=== Crossword Puzzle CSP Solver ===")
    words = []
    
    for i in range(7):
        word = input(f"Enter word {i + 1} (or press Enter to finish): ").strip().upper()
        if word == '':
            break
        words.append(word)

    if not words:
        print("Error: No words entered.")
        return

    # Initialize the grid based on the layout
    grid = [['' if crossword_layout[i][j] == '_' else '#' for j in range(grid_size)] for i in range(grid_size)]

    if solve_csp(0, grid, words):
        print("\nSolved Crossword Puzzle:\n")
        for i in range(grid_size):
            for j in range(grid_size):
                if crossword_layout[i][j] == '#':
                    print('█', end=' ')
                else:
                    print(grid[i][j] if grid[i][j] != '' else '.', end=' ')
            print()
    else:
        print("No solution found!")

if __name__ == "__main__":
    main()

"""
=== Crossword Puzzle CSP Solver ===
Enter word 1 (or press Enter to finish): happy
Enter word 2 (or press Enter to finish): holes
Enter word 3 (or press Enter to finish): year
Enter word 4 (or press Enter to finish): puppy
Enter word 5 (or press Enter to finish): lip
Enter word 6 (or press Enter to finish): style
Enter word 7 (or press Enter to finish): paa


Enter word 1 (or press Enter to finish): stone
Enter word 2 (or press Enter to finish): notes
Enter word 3 (or press Enter to finish): tone
Enter word 4 (or press Enter to finish): ten
Enter word 5 (or press Enter to finish): set
Enter word 6 (or press Enter to finish): one
Enter word 7 (or press Enter to finish): net


"""