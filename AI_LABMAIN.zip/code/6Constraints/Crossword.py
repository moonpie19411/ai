import tkinter as tk
from tkinter import messagebox
from tkinter import simpledialog

# Modified 5x5 layout (since the layout only has 5 rows)
# This represents the crossword grid where '_' are empty spaces, and '#' are blocked cells
crossword_layout = [
    ['_', '_', '_', '_', '_'],
    ['_', '#', '_', '#', '_'],
    ['_', '_', '_', '_', '_'],
    ['_', '#', '_', '#', '_'],
    ['_', '_', '_', '_', '_']
]

# The size of the grid (5x5 in this case)
grid_size = len(crossword_layout)

# Initialize empty lists for labels (used in GUI) and user word entries
labels = [[None for _ in range(grid_size)] for _ in range(grid_size)]
word_entries = []

# Function to check if a word can be placed in the grid at a given position
def is_valid(word, row, col, direction, grid):
    # Iterate over the word to check if placement is valid
    for k in range(len(word)):
        # Calculate row and column for vertical ('V') or horizontal ('H') direction
        r, c = (row + k, col) if direction == 'V' else (row, col + k)
        
        # Check if position is out of bounds or blocked ('#')
        if r >= grid_size or c >= grid_size or crossword_layout[r][c] == '#':
            return False
        
        # Check if the cell is already filled and not with the correct letter
        if grid[r][c] not in ('', word[k]):
            return False
    return True

# Function to place the word on the grid
def place_word(word, row, col, direction, grid):
    placed = []
    for k in range(len(word)):
        # Calculate position based on direction
        r, c = (row + k, col) if direction == 'V' else (row, col + k)
        
        # If cell is empty, place the letter
        if grid[r][c] == '':
            grid[r][c] = word[k]
            placed.append((r, c))  # Keep track of placed cells
    return placed

# Function to remove a previously placed word from the grid
def remove_word(placed, grid):
    for r, c in placed:
        grid[r][c] = ''  # Reset the cell to empty

# Function to solve the crossword puzzle using backtracking (CSP solver)
def solve_csp(index, grid, words):
    # Base case: if all words are placed, return True (solution found)
    if index == len(words):
        return True
    
    word = words[index]  # Get the current word to place
    
    # Try placing the word in all positions and directions
    for i in range(grid_size):
        for j in range(grid_size):
            for direction in ['H', 'V']:  # Horizontal or Vertical
                if is_valid(word, i, j, direction, grid):  # Check if valid placement
                    placed = place_word(word, i, j, direction, grid)  # Place the word
                    if solve_csp(index + 1, grid, words):  # Recursively solve the next word
                        return True
                    remove_word(placed, grid)  # If not successful, remove the word and backtrack
    
    return False  # No solution found if all placements fail

# Function to solve the puzzle using user input words
def solve():
    # Get words entered by the user and clean up input (remove extra spaces, uppercase)
    user_words = [entry.get().strip().upper() for entry in word_entries if entry.get().strip()]
    
    # Show error message if no valid words are entered
    if not user_words:
        messagebox.showerror("Input Error", "Please enter at least one word.")
        return

    # Create an empty grid based on the crossword layout, filling blocked cells with '#' and empty with ''
    grid = [['' if crossword_layout[i][j] == '_' else '#' for j in range(grid_size)] for i in range(grid_size)]

    # Try to solve the crossword puzzle using backtracking
    if solve_csp(0, grid, user_words):
        # If a solution is found, update the GUI grid with the solved puzzle
        for i in range(grid_size):
            for j in range(grid_size):
                if crossword_layout[i][j] == '#':
                    labels[i][j]['text'] = ''  # Clear the text in blocked cells
                    labels[i][j]['bg'] = 'black'  # Set blocked cells to black
                else:
                    labels[i][j]['text'] = grid[i][j]  # Set the letter in empty cells
                    labels[i][j]['bg'] = 'white'  # Set empty cells to white
    else:
        # If no solution is found, show a message to the user
        messagebox.showinfo("Result", "No solution found!")

# GUI setup
root = tk.Tk()
root.title("Crossword Puzzle CSP Solver")

# Title label for the window
title_label = tk.Label(root, text="Crossword Puzzle CSP Solver", font=("Arial", 14))
title_label.pack(pady=10)

# Frame for entering words
entry_frame = tk.Frame(root)
entry_frame.pack()

# Label instructing the user to enter words
tk.Label(entry_frame, text="Enter words (up to 7):", font=("Arial", 12)).pack()

# Create entry fields for the user to input words
for _ in range(7):
    entry = tk.Entry(entry_frame, font=("Arial", 12))
    entry.pack(pady=2)
    word_entries.append(entry)  # Add the entry field to the word_entries list

# Frame to display the crossword grid
grid_frame = tk.Frame(root)
grid_frame.pack(pady=10)

# Create labels for each cell in the crossword grid (5x5)
for i in range(grid_size):
    for j in range(grid_size):
        # Set background color based on whether the cell is blocked or empty
        bg_color = 'white' if crossword_layout[i][j] == '_' else 'black'
        labels[i][j] = tk.Label(grid_frame, width=4, height=2, relief='solid',
                                font=('Arial', 12), bg=bg_color)
        labels[i][j].grid(row=i, column=j)  # Place the label in the grid

# Button to solve the puzzle
solve_button = tk.Button(root, text="Solve Puzzle", command=solve)
solve_button.pack(pady=10)

# Run the GUI loop
root.mainloop()
