import random

class Puzzle:
    def __init__(self, board):  # Fix the constructor
        self.board = board
        self.size = 3  # 3x3 puzzle

    def get_blank_position(self):
        """Finds the position of the blank (0) tile."""
        for i in range(self.size):
            for j in range(self.size):
                if self.board[i][j] == 0:
                    return i, j

    def get_possible_moves(self):
        """Returns a list of possible moves (up, down, left, right)."""
        moves = []
        row, col = self.get_blank_position()
        
        if row > 0: moves.append("up")
        if row < self.size - 1: moves.append("down")
        if col > 0: moves.append("left")
        if col < self.size - 1: moves.append("right")
        
        return moves

    def move(self, direction):
        """Moves the blank tile in the given direction."""
        row, col = self.get_blank_position()
        new_board = [row[:] for row in self.board]

        if direction == "up":
            new_board[row][col], new_board[row-1][col] = new_board[row-1][col], new_board[row][col]
        elif direction == "down":
            new_board[row][col], new_board[row+1][col] = new_board[row+1][col], new_board[row][col]
        elif direction == "left":
            new_board[row][col], new_board[row][col-1] = new_board[row][col-1], new_board[row][col]
        elif direction == "right":
            new_board[row][col], new_board[row][col+1] = new_board[row][col+1], new_board[row][col]

        return Puzzle(new_board)

    def heuristic(self):
        """Calculates the heuristic (number of misplaced tiles)."""
        goal = [[1, 2, 3], [4, 5, 6], [7, 8, 0]]
        misplaced = sum(
            1 for i in range(self.size) for j in range(self.size) 
            if self.board[i][j] != goal[i][j] and self.board[i][j] != 0
        )
        return misplaced

    def __str__(self):  # Fix the string representation method
        """Prints the puzzle board with proper alignment while showing 0 as it is."""
        display = ""
        for row in self.board:
            display += " ".join(f"{num:>2}" for num in row) + "\n"
        return display

def hill_climbing(puzzle):
    """Solves the 8-puzzle using the Hill Climbing algorithm."""
    current = puzzle
    while True:
        print("Current State:\n", current)
        neighbors = [current.move(move) for move in current.get_possible_moves()]
        
        # Find the best move (with the lowest heuristic)
        best_neighbor = min(neighbors, key=lambda x: x.heuristic(), default=None)

        if best_neighbor and best_neighbor.heuristic() < current.heuristic():
            current = best_neighbor
        else:
            # Stuck in local minimum or reached goal state
            print("Reached Local Minimum or Goal State!")
            return current

def get_user_input():
    """Gets the initial board configuration from the user."""
    print("Enter the initial board configuration (use 0 for the blank space):")
    board = []
    for i in range(3):
        row = input(f"Enter row {i+1} (space-separated, e.g., '1 2 3'): ").split()
        row = [int(num) for num in row]
        if len(row) != 3:
            print("Each row must have exactly 3 numbers.")
            return get_user_input()  # Retry if input is invalid
        board.append(row)
    
    # Validate the board configuration
    flat_board = [num for row in board for num in row]
    if sorted(flat_board) != list(range(9)):
        print("Invalid board! Must contain numbers from 0 to 8 exactly once.")
        return get_user_input()
    
    return board

# Get user input for initial board configuration
initial_board = get_user_input()
puzzle = Puzzle(initial_board)

# Solve using hill climbing
solution = hill_climbing(puzzle)
print("Final State:\n", solution)

"""
input:
  
Enter the initial board configuration (use 0 for the blank space):
Enter row 1 (space-separated, e.g., '1 2 3'): 1 2 3
Enter row 2 (space-separated, e.g., '1 2 3'): 4 5 6
Enter row 3 (space-separated, e.g., '1 2 3'): 7 0 8
"""