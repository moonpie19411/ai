import heapq
import matplotlib.pyplot as plt
import numpy as np

DIRECTIONS = [(0, 1), (0, -1), (1, 0), (-1, 0)]

def heuristic(a, b):
    """Calculate Manhattan distance heuristic."""
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

def a_star(grid, start, goal):
    """Performs A* Search on the grid."""
    rows, cols = len(grid), len(grid[0])
    open_set = [(heuristic(start, goal), 0, start)]  # (f = g + h, g, node)
    came_from = {start: None}
    g_score = {start: 0}
    visited = set()

    while open_set:
        f, g, current = heapq.heappop(open_set)

        if current == goal:
            return reconstruct_path(came_from, goal)

        if current in visited:
            continue
        visited.add(current)

        for dx, dy in DIRECTIONS:
            neighbor = (current[0] + dx, current[1] + dy)
            if 0 <= neighbor[0] < rows and 0 <= neighbor[1] < cols and grid[neighbor[0]][neighbor[1]] == 0:
                tentative_g_score = g + 1  # all moves cost 1
                if neighbor not in g_score or tentative_g_score < g_score[neighbor]:
                    g_score[neighbor] = tentative_g_score
                    f_score = tentative_g_score + heuristic(neighbor, goal)
                    heapq.heappush(open_set, (f_score, tentative_g_score, neighbor))
                    came_from[neighbor] = current

    return []  # No path found

def reconstruct_path(parent_map, goal):
    """Reconstruct path from start to goal using the parent map."""
    path = []
    current = goal
    while current is not None:
        path.append(current)
        current = parent_map[current]
    return path[::-1]

def visualize(grid, path, start, goal):
    """Visualizes the grid and the path using Matplotlib."""
    grid_array = np.array(grid)
    plt.imshow(grid_array, cmap="gray_r")

    for (x, y) in path:
        plt.scatter(y, x, c='blue', s=100)  # Path visualization

    plt.scatter(start[1], start[0], c='green', s=100, label='Start')
    plt.scatter(goal[1], goal[0], c='red', s=100, label='Goal')
    plt.legend()
    plt.title("A* Pathfinding Visualization")
    plt.show()

def get_user_input():
    """Takes user input for grid size, obstacles, start, and goal positions."""
    rows = int(input("Enter number of rows: "))
    cols = int(input("Enter number of columns: "))

    grid = np.zeros((rows, cols), dtype=int)

    num_obstacles = int(input("Enter number of obstacles: "))
    
    print("Enter obstacle positions (row col): ")
    for _ in range(num_obstacles):
        r, c = map(int, input().split())
        if 0 <= r < rows and 0 <= c < cols:
            grid[r][c] = 1  # Mark obstacle
        else:
            print(f"Invalid obstacle position: ({r}, {c})")

    start_x, start_y = map(int, input("Enter start position (row col): ").split())
    goal_x, goal_y = map(int, input("Enter goal position (row col): ").split())

    start = (start_x, start_y)
    goal = (goal_x, goal_y)

    return grid, start, goal

# Main driver
grid, start, goal = get_user_input()
path = a_star(grid, start, goal)
visualize(grid, path, start, goal)

"""Enter number of rows: 6
Enter number of columns: 6
Enter number of obstacles: 5
Enter obstacle positions (row col): 
1 2
2 2
3 2
4 2
4 3
Enter start position (row col): 0 0
Enter goal position (row col): 5 5
"""