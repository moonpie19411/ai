import heapq
from copy import deepcopy

class NPuzzleSolver:
    def __init__(self, initial_board):
        self.size = len(initial_board)
        self.initial_state = self.Node(initial_board)
        
    class Node:
        def __init__(self, board, parent=None, move=None):
            self.board = board
            self.parent = parent
            self.move = move
            self.g = 0 if parent is None else parent.g + 1
            self.h = self.calculate_heuristic()
            self.blank_pos = self.find_blank()

        def find_blank(self):
            for i in range(len(self.board)):
                for j in range(len(self.board)):
                    if self.board[i][j] == 0:
                        return (i, j)
            return None

        def calculate_heuristic(self):
            h = 0
            n = len(self.board)
            for i in range(n):
                for j in range(n):
                    val = self.board[i][j]
                    if val != 0:
                        goal_row = (val - 1) // n
                        goal_col = (val - 1) % n
                        h += abs(i - goal_row) + abs(j - goal_col)
            return h

        def is_goal(self):
            n = len(self.board)
            num = 1
            for i in range(n):
                for j in range(n):
                    if i == n - 1 and j == n - 1:
                        if self.board[i][j] != 0:
                            return False
                    else:
                        if self.board[i][j] != num:
                            return False
                        num += 1
            return True

        def get_neighbors(self):
            neighbors = []
            i, j = self.blank_pos
            moves = [(0, 1), (1, 0), (0, -1), (-1, 0)]  # Right, Down, Left, Up
            for di, dj in moves:
                ni, nj = i + di, j + dj
                if 0 <= ni < len(self.board) and 0 <= nj < len(self.board):
                    new_board = deepcopy(self.board)
                    new_board[i][j], new_board[ni][nj] = new_board[ni][nj], new_board[i][j]
                    neighbors.append(NPuzzleSolver.Node(new_board, self, (di, dj)))
            return neighbors

        def __lt__(self, other):
            return (self.g + self.h) < (other.g + other.h)

        def __eq__(self, other):
            return self.board == other.board

        def __hash__(self):
            return hash(tuple(tuple(row) for row in self.board))

        def __str__(self):
            return '\n'.join([' '.join(map(str, row)) for row in self.board])

    def solve(self):
        open_set = []
        heapq.heappush(open_set, self.initial_state)
        closed_set = set()

        while open_set:
            current = heapq.heappop(open_set)

            if current.is_goal():
                path = []
                while current.parent is not None:
                    path.append(current)
                    current = current.parent
                path.append(current)
                path.reverse()
                return path

            closed_set.add(current)

            for neighbor in current.get_neighbors():
                if neighbor in closed_set:
                    continue
                if neighbor not in open_set:
                    heapq.heappush(open_set, neighbor)
                else:
                    for node in open_set:
                        if node == neighbor and node.g > neighbor.g:
                            node.g = neighbor.g
                            node.parent = neighbor.parent
                            heapq.heapify(open_set)
                            break
        return None

# ---- INPUT SECTION ----
def get_user_input():
    n = int(input("Enter puzzle size (n for n x n): ").strip())
    print(f"Enter {n * n} numbers (0 for blank tile), row-wise:")
    flat_input = []
    while len(flat_input) < n * n:
        try:
            nums = list(map(int, input().strip().split()))
            flat_input.extend(nums)
        except ValueError:
            print("Invalid input. Enter integers only.")
    if len(flat_input) != n * n:
        print("Incorrect number of tiles entered.")
        sys.exit(1)
    board = [flat_input[i * n:(i + 1) * n] for i in range(n)]
    return board

if __name__ == "__main__":
    board = get_user_input()
    solver = NPuzzleSolver(board)
    solution = solver.solve()
    if solution:
        print("Solution found in", len(solution)-1, "moves:")
        for i, state in enumerate(solution):
            if i > 0:
                print(f"\nMove {i}: {state.move}")
            print(state)
    else:
        print("No solution found.")

"""
Enter puzzle size (n for n x n): 3
Enter 9 numbers (0 for blank tile), row-wise:
1 2 3
4 0 6
7 5 8
"""