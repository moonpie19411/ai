import heapq
import networkx as nx
import matplotlib.pyplot as plt

def a_star(graph, heuristics, start, goal):
    """A* search algorithm to find the shortest path from start to goal."""
    priority_queue = [(0 + heuristics[start], 0, start, [])]  # (f(n), g(n), current, path)
    visited = set()
    
    while priority_queue:
        f, g, current, path = heapq.heappop(priority_queue)

        if current in visited:
            continue
        visited.add(current)

        path = path + [current]

        if current == goal:
            return path, g  # Return shortest path and total cost
        
        for neighbor, cost in graph[current].items():
            if neighbor not in visited:
                g_new = g + cost
                f_new = g_new + heuristics[neighbor]  # f(n) = g(n) + h(n)
                heapq.heappush(priority_queue, (f_new, g_new, neighbor, path))

    return None, float('inf')  # No path found

def visualize_graph(graph, path):
    """Visualize the graph and the shortest path."""
    G = nx.Graph()
    
    for city in graph:
        for neighbor, distance in graph[city].items():
            G.add_edge(city, neighbor, weight=distance)

    pos = nx.spring_layout(G)  # Positioning nodes
    edge_labels = {(u, v): f"{graph[u][v]}" for u, v in G.edges()}

    # Draw the full graph
    nx.draw(G, pos, with_labels=True, node_color='lightgray', edge_color='gray', node_size=2000, font_size=10)
    nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels, font_size=8)

    # Highlight the shortest path
    if path:
        path_edges = list(zip(path, path[1:]))
        nx.draw(G, pos, with_labels=True, node_color='lightblue', node_size=2000, font_size=10)
        nx.draw_networkx_edges(G, pos, edgelist=path_edges, edge_color='red', width=2)
    
    plt.title("City Graph with A* Shortest Path")
    plt.show()

# Taking user input
num_cities = int(input("Enter number of cities: "))
graph = {}
heuristics = {}

print("Enter city names:")
cities = [input().strip() for _ in range(num_cities)]

for city in cities:
    graph[city] = {}

num_roads = int(input("Enter number of roads: "))

print("Enter roads in format: City1 City2 Distance")
for _ in range(num_roads):
    city1, city2, distance = input().split()
    distance = int(distance)
    graph[city1][city2] = distance
    graph[city2][city1] = distance  # Since it's an undirected graph

print("Enter heuristic values (straight-line distance to goal):")
for city in cities:
    heuristics[city] = int(input(f"Heuristic for {city}: "))

start = input("Enter start city: ").strip()
goal = input("Enter goal city: ").strip()

# Running A* search
shortest_path, total_cost = a_star(graph, heuristics, start, goal)

# Displaying results
if shortest_path:
    print("\nShortest Path:", " → ".join(shortest_path))
    print("Total Cost:", total_cost)
    """visualize_graph(graph, shortest_path) """
else:
    print("No path found.")

"""
Enter number of cities: 5
Enter city names:
Pune
Nashik
Satara
Sangli
Kolhapur
Enter number of roads: 6
Enter roads in format: City1 City2 Distance
Pune Satara 110
Satara Sangli 50
Sangli Kolhapur 50
Pune Nashik 210
Nashik Kolhapur 300
Pune Kolhapur 250
Enter heuristic values (straight-line distance to goal):
Heuristic for Pune: 250
Heuristic for Nashik: 300
Heuristic for Satara: 100
Heuristic for Sangli: 60
Heuristic for Kolhapur: 0
Enter start city: Pune
Enter goal city: Kolhapur

Shortest Path: Pune → Satara → Sangli → Kolhapur
Total Cost: 210"""